/***

http://veersuthar.com/blogs/2017/01/04/update-and-delete-in-core-data-in-ios10-swift-3/
http://veersuthar.com/blogs/2017/01/01/how-to-use-core-data-in-ios-10-swift-3/

1. Add Entety
2. Add Attribute.
