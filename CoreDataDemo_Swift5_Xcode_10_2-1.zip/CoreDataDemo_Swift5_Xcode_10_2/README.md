# CoreData
CoreData Demo (insert,update &amp; delete).
