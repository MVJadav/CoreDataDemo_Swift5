//
//  UserListVCCell.swift
//  DataBaseTest
//
//  Created by MVJadav.
//  Copyright © 2019 MVJadav. All rights reserved.
//

import UIKit

class UserListVCCell: UITableViewCell {

    @IBOutlet weak var IBname: UILabel!
    @IBOutlet weak var IBlblNumber: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setView()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}

extension UserListVCCell {
    
    func setView() {
        self.IBname.text = ""
        self.IBlblNumber.text = ""
    }

}
